"""
Run all test suites in sequence.
Usage: python run_all_tests.py
"""
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

from tests.test_header          import test_header
from tests.test_homepage        import test_homepage
from tests.test_book_a_demo     import test_book_a_demo
from tests.test_get_started_free import test_get_started_free

if __name__ == "__main__":
    test_header()
    test_homepage()
    test_book_a_demo()
    test_get_started_free()
