import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from utils.helpers import get_driver, get_wait
from pages.home_page import HomePage
from config.config import BASE_URL
import time

def test_homepage():
    driver = get_driver()
    driver.get(BASE_URL + "/")
    wait = get_wait(driver)

    print("\n========== HOMEPAGE TESTS ==========")
    home = HomePage(driver, wait, BASE_URL)

    home.check_get_started_free()
    home.check_book_demo()
    home.check_all_product_links()
    home.check_how_it_works_field()
    home.check_pricing_links()
    home.check_industry_tabs()
    home.check_footer_links()

    time.sleep(1)
    driver.quit()
    print("\n========== HOMEPAGE TESTS DONE ==========")

if __name__ == "__main__":
    test_homepage()
