import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from utils.helpers import get_driver, get_wait
from pages.book_demo_page import BookDemoPage
from config.config import BASE_URL, TEST_DATA
import time

def test_book_a_demo():
    driver = get_driver()
    driver.get(BASE_URL + "/book-demo")
    wait = get_wait(driver)

    print("\n========== BOOK A DEMO TESTS ==========")
    page = BookDemoPage(driver, wait, BASE_URL)

    page.click_back_to_homepage()
    page.click_book_demo_from_header()
    page.click_schedule_demo()
    page.test_name_field(TEST_DATA["name"])
    page.test_email_field(TEST_DATA["email"])
    page.test_company_field(TEST_DATA["company"])
    page.test_company_size_dropdown()
    page.test_optional_field(BASE_URL + "/book-demo")

    calendar_dates, today_day = page.test_calendar()
    page.book_first_available_slot(calendar_dates, today_day)

    time.sleep(1)
    driver.quit()
    print("\n========== BOOK A DEMO TESTS DONE ==========")

if __name__ == "__main__":
    test_book_a_demo()
