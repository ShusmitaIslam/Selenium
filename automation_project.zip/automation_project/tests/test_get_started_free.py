import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from utils.helpers import get_driver, get_wait
from pages.get_started_free_page import GetStartedFreePage
from config.config import BASE_URL, TEST_DATA
import time

def test_get_started_free():
    driver = get_driver()
    driver.get(BASE_URL + "/signup")
    wait = get_wait(driver)

    print("\n========== GET STARTED FREE TESTS ==========")
    page = GetStartedFreePage(driver, wait, BASE_URL)

    # ── Page load checks ──
    page.check_page_loaded()
    page.check_step_indicator()
    page.check_tos_and_privacy_links()
    page.check_back_to_homepage()

    # ── Credentials (Step 1) ──
    page.fill_credentials(TEST_DATA["work_email"], TEST_DATA["password"])

    # ── OTP ──
    page.test_otp_field(TEST_DATA["otp"])
    page.test_resend_otp()
    page.verify_otp()

    # ── Profile info (Step 2+) ──
    page.check_step2_heading()
    page.test_first_last_name(TEST_DATA["name"])
    page.test_company_name(TEST_DATA["company_signup"])
    page.test_industry_dropdown()
    page.test_team_size_dropdown()
    page.test_country_dropdown()
    page.test_address_fields(
        TEST_DATA["address_line_1"],
        TEST_DATA["address_line_2"],
        TEST_DATA["city"],
        TEST_DATA["postal_code"],
        TEST_DATA["phone_number"],
    )

    # ── Module selection ──
    page.test_module_selection()

    time.sleep(1)
    driver.quit()
    print("\n========== GET STARTED FREE TESTS DONE ==========")

if __name__ == "__main__":
    test_get_started_free()
