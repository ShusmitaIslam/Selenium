import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from utils.helpers import get_driver, get_wait
from pages.header_page import HeaderPage
from config.config import BASE_URL
import time

def test_header():
    driver = get_driver()
    driver.get(BASE_URL + "/")
    wait = get_wait(driver)

    print("\n========== HEADER TESTS ==========")
    header = HeaderPage(driver, wait)

    header.check_all_elements_visible()
    header.click_product_and_verify_scroll()
    header.click_pricing_and_verify_scroll()
    header.click_book_a_demo(BASE_URL + "/book-demo")

    driver.get(BASE_URL + "/")
    time.sleep(1)

    header.click_get_started(BASE_URL + "/signup")

    time.sleep(1)
    driver.quit()
    print("\n========== HEADER TESTS DONE ==========")

if __name__ == "__main__":
    test_header()
