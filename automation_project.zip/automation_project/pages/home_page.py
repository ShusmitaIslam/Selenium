from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from utils.helpers import go_back_home, check_url_changed
import time


class HomePage:
    """Locators and actions for the main landing page."""

    # ── Locators ──────────────────────────────────────────────────────
    BTN_GET_STARTED = (By.XPATH, '//*[@id="root"]/div/main/section[1]/div/div[1]/div/a[1]')
    BTN_BOOK_DEMO   = (By.XPATH, '//*[@id="root"]/div/main/section[1]/div/div[1]/div/a[2]')
    LOGO_IMG        = (By.XPATH, '//*[@id="root"]/div/nav/div/a/img')

    # Product links
    PRODUCT_LINKS = {
        "HR"                  : '//*[@id="product"]/div/div[2]/a[1]',
        "Accounting"          : '//*[@id="product"]/div/div[2]/a[2]',
        "Property Management" : '//*[@id="product"]/div/div[2]/a[3]',
        "CRM"                 : '//*[@id="product"]/div/div[2]/a[4]',
        "Point of Sales"      : '//*[@id="product"]/div/div[2]/a[5]',
        "Sales"               : '//*[@id="product"]/div/div[2]/a[6]',
        "Purchase"            : '//*[@id="product"]/div/div[2]/a[7]',
        "Manufacturing"       : '//*[@id="product"]/div/div[2]/a[8]',
        "Support"             : '//*[@id="product"]/div/div[2]/a[9]',
    }

    # How it works
    HOW_IT_WORKS_FIELD = (By.XPATH, '//*[@id="root"]/div/main/section[3]/div/div[2]/div[2]')

    # Pricing links
    PRICING_FREEMIUM = (By.XPATH, '//*[@id="pricing"]/div/div[2]/div[1]/a')
    PRICING_GROWTH   = (By.XPATH, '//*[@id="pricing"]/div/div[2]/div[2]/a')
    PRICING_CUSTOM   = (By.XPATH, '//*[@id="pricing"]/div/div[2]/div[3]/a')
    PRICING_GET_STARTED = (By.XPATH, '//*[@id="pricing"]/div/div[2]/div[3]/a')
    PRICING_BOOK_DEMO   = (By.XPATH, '//*[@id="pricing"]/div/div[2]/div[3]/a')

    # Built for your industry tabs
    INDUSTRY_TABS = {
        "Real Estate"   : '//*[@id="solutions"]/div/div[2]/button[1]',
        "Construction"  : '//*[@id="solutions"]/div/div[2]/button[2]',
        "Manufacturing" : '//*[@id="solutions"]/div/div[2]/button[3]',
        "Services"      : '//*[@id="solutions"]/div/div[2]/button[4]',
    }
    INDUSTRY_SECTION = (By.XPATH, '//*[@id="solutions"]/div/div[3]/div[1]/p')

    # Footer links
    FOOTER_LINKS = {
        "HR"                 : '//*[@id="root"]/div/footer/div/div[1]/div/ul/li[1]/a',
        "Accounting"         : '//*[@id="root"]/div/footer/div/div[1]/div/ul/li[2]/a',
        "Project Management" : '//*[@id="root"]/div/footer/div/div[1]/div/ul/li[3]/a',
        "CRM"                : '//*[@id="root"]/div/footer/div/div[1]/div/ul/li[4]/a',
        "Point of Sale"      : '//*[@id="root"]/div/footer/div/div[1]/div/ul/li[5]/a',
        "Sales"              : '//*[@id="root"]/div/footer/div/div[1]/div/ul/li[6]/a',
        "Purchase"           : '//*[@id="root"]/div/footer/div/div[1]/div/ul/li[7]/a',
        "Manufacturing"      : '//*[@id="root"]/div/footer/div/div[1]/div/ul/li[8]/a',
        "Support"            : '//*[@id="root"]/div/footer/div/div[1]/div/ul/li[9]/a',
    }

    def __init__(self, driver, wait, base_url):
        self.driver   = driver
        self.wait     = wait
        self.base_url = base_url

    # ── Helper ────────────────────────────────────────────────────────

    def _click_and_check(self, locator, label):
        """Click an element, verify URL changes, then navigate back home."""
        old_url = self.driver.current_url
        btn = self.wait.until(EC.element_to_be_clickable(locator))
        btn.click()
        check_url_changed(self.driver, self.wait, old_url, label)
        time.sleep(2)
        go_back_home(self.driver, self.wait, self.base_url)

    # ── Hero section ──────────────────────────────────────────────────

    def check_get_started_free(self):
        old_url = self.driver.current_url
        btn = self.wait.until(EC.element_to_be_clickable(self.BTN_GET_STARTED))
        btn.click()
        check_url_changed(self.driver, self.wait, old_url, "Get Started Free")
        time.sleep(2)
        go_back_home(self.driver, self.wait, self.base_url)

    def check_book_demo(self):
        old_url = self.driver.current_url
        btn = self.wait.until(EC.element_to_be_clickable(self.BTN_BOOK_DEMO))
        btn.click()
        check_url_changed(self.driver, self.wait, old_url, "Book a Demo")
        time.sleep(2)
        go_back_home(self.driver, self.wait, self.base_url)

    # ── Product section ───────────────────────────────────────────────

    def check_all_product_links(self):
        print("\nProducts redirection checking:")
        for name, xpath in self.PRODUCT_LINKS.items():
            self._click_and_check((By.XPATH, xpath), name)

    # ── How it works ──────────────────────────────────────────────────

    def check_how_it_works_field(self):
        field = self.wait.until(EC.visibility_of_element_located(self.HOW_IT_WORKS_FIELD))
        if field.is_displayed():
            print("✅ How it works field is visible")
        else:
            print("❌ How it works field is NOT visible")

        readonly = field.get_attribute("readonly")
        disabled = field.get_attribute("disabled")
        if readonly is not None or disabled is not None:
            print("✅ Field is NON-EDITABLE")
        else:
            print("❌ Field is EDITABLE")

    # ── Pricing section ───────────────────────────────────────────────

    def check_pricing_links(self):
        print("\nPricing:")
        self._click_and_check(self.PRICING_FREEMIUM,    "Pricing Freemium")
        self._click_and_check(self.PRICING_GROWTH,      "Pricing Growth")
        self._click_and_check(self.PRICING_CUSTOM,      "Pricing Custom")
        self._click_and_check(self.PRICING_GET_STARTED, "Get Started Free")
        self._click_and_check(self.PRICING_BOOK_DEMO,   "Book a Demo")

    # ── Industry tabs ─────────────────────────────────────────────────

    def check_industry_tabs(self):
        for name, xpath in self.INDUSTRY_TABS.items():
            tab = self.wait.until(EC.element_to_be_clickable((By.XPATH, xpath)))
            tab.click()
            section = self.wait.until(EC.visibility_of_element_located(self.INDUSTRY_SECTION))
            if section.is_displayed():
                print(f"✅ {name} section appeared after tab click")
            else:
                print(f"❌ {name} section did not appear")

    # ── Footer ────────────────────────────────────────────────────────

    def check_footer_links(self):
        print("\nFooter links:")
        for name, xpath in self.FOOTER_LINKS.items():
            self._click_and_check((By.XPATH, xpath), f"Footer - {name}")
