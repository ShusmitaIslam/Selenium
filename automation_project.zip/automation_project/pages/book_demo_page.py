from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from datetime import datetime
import time


class BookDemoPage:
    """Locators and actions for the Book a Demo page."""

    # ── Locators ──────────────────────────────────────────────────────
    BACK_HOME_LINK   = (By.CSS_SELECTOR, "#root > div > main > div > div > div.bg-white.border.border-gray-200.rounded-lg.p-8.space-y-6 > a")
    DEMO_BTN         = (By.CSS_SELECTOR, "a.border")
    SCHEDULE_BTN     = (By.CSS_SELECTOR, "#root > div > main > div > div > div.bg-white.border.border-gray-200.rounded-lg.p-8.space-y-6 > button")

    NAME_FIELD       = (By.NAME, "name")
    EMAIL_FIELD      = (By.NAME, "email")
    COMPANY_FIELD    = (By.NAME, "company")
    SOLVE_FIELD      = (By.NAME, "useCase")

    CONTINUE_BTN     = (By.XPATH, '//*[@id="root"]/div/main/div/div/div[2]/form/button')
    CONFIRM_BTN      = (By.XPATH, '//*[@id="root"]/div/main/div/div/div[2]/div/button')
    BACK_HOME_FINAL  = (By.XPATH, '//*[@id="root"]/div/main/div/div/div[2]/a')

    NAME_ERROR       = (By.XPATH, '//*[@id="root"]/div/main/div/div/div[2]/form/div[1]')
    EMAIL_ERROR      = (By.XPATH, '//*[@id="root"]/div/main/div/div/div[2]/form/div[2]/p')

    DROPDOWN         = (By.XPATH, '//*[@id="root"]/div/main/div/div/div[2]/form/div[4]')
    DROPDOWN_OPTIONS = (By.XPATH, "//*[contains(text(),'people') or contains(text(),'Select size')]")

    def __init__(self, driver, wait, base_url):
        self.driver   = driver
        self.wait     = wait
        self.base_url = base_url

    # ── Navigation ────────────────────────────────────────────────────

    def click_back_to_homepage(self):
        btn = self.wait.until(EC.visibility_of_element_located(self.BACK_HOME_LINK))
        btn.click()
        time.sleep(1)
        expected = self.base_url + "/"
        self.wait.until(EC.url_to_be(expected))
        status = "PASS" if self.driver.current_url == expected else "FAIL"
        print(f"{status}: User successfully redirected to Home page")

    def click_book_demo_from_header(self):
        btn = self.wait.until(EC.visibility_of_element_located(self.DEMO_BTN))
        btn.click()
        time.sleep(1)
        expected = self.base_url + "/book-demo"
        self.wait.until(EC.url_to_be(expected))
        status = "PASS" if self.driver.current_url == expected else "FAIL"
        print(f"{status}: User successfully redirected to Book a Demo page")

    def click_schedule_demo(self):
        btn = self.wait.until(EC.visibility_of_element_located(self.SCHEDULE_BTN))
        btn.click()
        time.sleep(1)
        expected = self.base_url + "/book-demo"
        self.wait.until(EC.url_to_be(expected))
        status = "PASS" if self.driver.current_url == expected else "FAIL"
        print(f"{status}: User successfully redirected to Schedule Demo page")

    # ── Form fields ───────────────────────────────────────────────────

    def test_name_field(self, test_name):
        name_field = self.wait.until(EC.visibility_of_element_located(self.NAME_FIELD))
        print("PASS: Name field is visible")

        # Empty validation
        name_field.clear()
        self.driver.find_element(*self.CONTINUE_BTN).click()
        time.sleep(1)
        error = self.wait.until(EC.visibility_of_element_located(self.NAME_ERROR))
        status = "PASS" if error.is_displayed() else "FAIL"
        print(f"{status}: Name required validation working")

        # Valid input
        name_field.clear()
        name_field.send_keys(test_name)
        time.sleep(1)
        status = "PASS" if name_field.get_attribute("value") == test_name else "FAIL"
        print(f"{status}: Name field accepts input correctly")

    def test_email_field(self, test_email):
        email_field = self.wait.until(EC.visibility_of_element_located(self.EMAIL_FIELD))
        print("PASS: Work Email field is visible")

        email_field.clear()
        self.driver.find_element(*self.CONTINUE_BTN).click()
        time.sleep(1)
        error = self.wait.until(EC.visibility_of_element_located(self.EMAIL_ERROR))
        if error.is_displayed():
            print("PASS: Work Email required validation working")
            print("INFO: Validation message:", error.text)
        else:
            print("FAIL: Work Email required validation not working")

        email_field.clear()
        email_field.send_keys(test_email)
        time.sleep(1)
        status = "PASS" if email_field.get_attribute("value") == test_email else "FAIL"
        print(f"{status}: Work Email field accepts input correctly")

    def test_company_field(self, test_company):
        company = self.wait.until(EC.visibility_of_element_located(self.COMPANY_FIELD))
        print("PASS: Company Name field is visible")

        company.clear()
        self.driver.find_element(*self.CONTINUE_BTN).click()
        time.sleep(1)
        error = self.wait.until(EC.visibility_of_element_located((By.XPATH, "//*[contains(text(),'Company')]")))
        if error.is_displayed():
            print("PASS: Company Name required validation working")
            print("INFO: Validation message:", error.text)
        else:
            print("FAIL: Company Name required validation not working")

        company.clear()
        company.send_keys(test_company)
        time.sleep(1)
        status = "PASS" if company.get_attribute("value") == test_company else "FAIL"
        print(f"{status}: Company Name field accepts input correctly")

    def test_company_size_dropdown(self):
        dropdown = self.wait.until(EC.element_to_be_clickable(self.DROPDOWN))
        dropdown.click()
        time.sleep(1)

        options = self.driver.find_elements(*self.DROPDOWN_OPTIONS)
        print(f"INFO: Total dropdown options found: {len(options)}")

        if options[0].text == "Select size":
            print("PASS: Placeholder option is correct")
        else:
            print("FAIL: Placeholder option mismatch")

        for i in range(1, len(options)):
            dropdown.click()
            time.sleep(1)
            options = self.driver.find_elements(*self.DROPDOWN_OPTIONS)
            option_text = options[i].text
            options[i].click()
            time.sleep(1)
            print(f"PASS: Successfully selected: {option_text}")
            if option_text in dropdown.text:
                print(f"PASS: {option_text} selection working correctly")
            else:
                print(f"FAIL: {option_text} selection failed")

    def test_optional_field(self, expected_schedule_url):
        solve_field = self.wait.until(EC.visibility_of_element_located(self.SOLVE_FIELD))
        print("PASS: 'What are you looking to solve?' field is visible")

        solve_field.clear()
        self.driver.find_element(*self.CONTINUE_BTN).click()
        time.sleep(2)

        current_url = self.driver.current_url
        print("INFO: Current URL after submit:", current_url)

        if current_url != expected_schedule_url:
            print("PASS: Optional field allows empty submission (URL changed)")
        else:
            errors = self.driver.find_elements(By.XPATH, "//*[contains(text(),'required')]")
            optional_error = any("solve" in e.text.lower() for e in errors)
            if optional_error:
                print("FAIL: Optional field incorrectly showing validation error")
            else:
                print("PASS: Optional field allows empty submission")

    # ── Calendar ──────────────────────────────────────────────────────

    def _get_calendar_header_text(self):
        candidate_xpaths = [
            '//*[@id="root"]/div/main/div/div/div[2]/div/div[2]/div[1]/span',
            '//*[@id="root"]/div/main/div/div/div[2]/div/div[2]/div[1]/h2',
            '//*[@id="root"]/div/main/div/div/div[2]/div/div[2]/div[1]/p',
            '//*[@id="root"]/div/main/div/div/div[2]/div/div[2]/div[1]/div[1]',
            "//div[contains(@class,'calendar')]//span[contains(text(),'2026') or contains(text(),'2025')]",
            "//div[contains(@class,'month')]",
            "//*[contains(@class,'calendar-header')]",
            "//*[contains(@class,'month-year')]",
        ]
        for xpath in candidate_xpaths:
            try:
                el = self.driver.find_element(By.XPATH, xpath)
                text = el.text.strip()
                if text:
                    return text
            except Exception:
                continue
        return None

    def _parse_month_year(self, text):
        months = {
            "January": 1, "February": 2, "March": 3, "April": 4,
            "May": 5, "June": 6, "July": 7, "August": 8,
            "September": 9, "October": 10, "November": 11, "December": 12,
        }
        for month_name, month_num in months.items():
            if month_name in text:
                parts = text.split()
                for part in parts:
                    if part.isdigit() and len(part) == 4:
                        return month_num, int(part)
        return None, None

    def _navigate_to_current_month(self, current_month, current_year):
        for _ in range(12):
            header_text = self._get_calendar_header_text()
            if not header_text:
                break
            month, year = self._parse_month_year(header_text)
            if month == current_month and year == current_year:
                print(f"INFO: Calendar is on the correct month: {header_text}")
                break
            if year < current_year or (year == current_year and month < current_month):
                try:
                    next_btn = self.driver.find_element(
                        By.XPATH,
                        "//button[contains(@aria-label,'next') or contains(@class,'next') or contains(text(),'>')]"
                    )
                    next_btn.click()
                    time.sleep(1)
                except Exception:
                    break
            else:
                break

    def _get_calendar_dates(self):
        from selenium.webdriver.common.by import By
        date_buttons = self.driver.find_elements(
            By.XPATH,
            "//button[string-length(normalize-space(text())) <= 2 and translate(normalize-space(text()),'0123456789','') = '']"
        )
        calendar_dates = {}
        for btn in date_buttons:
            txt = btn.text.strip()
            if txt.isdigit():
                calendar_dates[int(txt)] = btn
        return calendar_dates

    def test_calendar(self):
        today         = datetime.today()
        today_day     = today.day
        current_month = today.month
        current_year  = today.year

        print(f"INFO: Today is {today.strftime('%B %d, %Y')}")

        self._navigate_to_current_month(current_month, current_year)

        calendar_dates = self._get_calendar_dates()
        print(f"INFO: Calendar dates found: {sorted(calendar_dates.keys())}")

        # Past date check
        yesterday_day = today_day - 1
        if yesterday_day > 0 and yesterday_day in calendar_dates:
            btn        = calendar_dates[yesterday_day]
            class_name = btn.get_attribute("class").lower()
            is_disabled = (
                "disabled" in class_name or "unavailable" in class_name
                or "cursor-not-allowed" in class_name
                or btn.get_attribute("disabled") is not None
            )
            status = "PASS" if is_disabled else "FAIL"
            print(f"{status}: Past date ({yesterday_day}) is {'DISABLED' if is_disabled else 'NOT disabled'}")

        # Today enabled check
        if today_day in calendar_dates:
            btn        = calendar_dates[today_day]
            class_name = btn.get_attribute("class").lower()
            is_disabled = (
                "disabled" in class_name or "unavailable" in class_name
                or "cursor-not-allowed" in class_name
                or btn.get_attribute("disabled") is not None
            )
            status = "PASS" if not is_disabled else "FAIL"
            print(f"{status}: Today ({today_day}) is {'ENABLED' if not is_disabled else 'DISABLED'}")

        # Tomorrow enabled check
        tomorrow_day = today_day + 1
        if tomorrow_day in calendar_dates:
            btn        = calendar_dates[tomorrow_day]
            class_name = btn.get_attribute("class").lower()
            is_disabled = (
                "disabled" in class_name or "unavailable" in class_name
                or "cursor-not-allowed" in class_name
                or btn.get_attribute("disabled") is not None
            )
            status = "PASS" if not is_disabled else "FAIL"
            print(f"{status}: Tomorrow ({tomorrow_day}) is {'ENABLED' if not is_disabled else 'DISABLED'}")

        return calendar_dates, today_day

    def book_first_available_slot(self, calendar_dates, today_day):
        date_selected      = False
        first_selected_day = None

        for day in range(today_day, today_day + 10):
            if day not in calendar_dates:
                print(f"INFO: Date {day} not found on calendar, skipping")
                continue

            btn        = calendar_dates[day]
            class_name = btn.get_attribute("class").lower()
            is_disabled = (
                "disabled" in class_name or "unavailable" in class_name
                or "cursor-not-allowed" in class_name
                or btn.get_attribute("disabled") is not None
            )
            is_holiday = "holiday" in class_name

            if is_disabled:
                print(f"FAIL: Date {day} is disabled")
                continue
            print(f"PASS: Date {day} is enabled")

            if is_holiday:
                print(f"INFO: Date {day} is a Public Holiday, skipping")
                continue
            print(f"PASS: Date {day} is not a Public Holiday")

            self.driver.execute_script("arguments[0].scrollIntoView({block:'center'});", btn)
            time.sleep(1)
            self.driver.execute_script("arguments[0].click();", btn)
            print(f"INFO: Selected Date: {day}")
            date_selected      = True
            first_selected_day = day
            break

        if not date_selected:
            print("FAIL: No selectable date found in the next 10 days")

        booking_confirmed = False
        time.sleep(2)

        for day in range(today_day, today_day + 14):
            if day == first_selected_day and date_selected:
                pass
            else:
                if day not in calendar_dates:
                    continue
                btn        = calendar_dates[day]
                class_name = btn.get_attribute("class").lower()
                is_disabled = (
                    "disabled" in class_name or "unavailable" in class_name
                    or "cursor-not-allowed" in class_name
                    or btn.get_attribute("disabled") is not None
                )
                if is_disabled:
                    print(f"INFO: Date {day} is disabled, trying next date")
                    continue
                self.driver.execute_script("arguments[0].scrollIntoView({block:'center'});", btn)
                time.sleep(0.5)
                self.driver.execute_script("arguments[0].click();", btn)
                print(f"INFO: Trying Date: {day}")
                time.sleep(2)

            time.sleep(3)

            # Collect time slot buttons
            time_slot_buttons = []
            all_btns = self.driver.find_elements(By.TAG_NAME, "button")
            for b in all_btns:
                txt = b.text.strip()
                if "AM" in txt or "PM" in txt:
                    time_slot_buttons.append(b)

            print(f"INFO: Time slot buttons collected: {len(time_slot_buttons)}")

            if not time_slot_buttons:
                print(f"INFO: No time slots found for date {day}, trying next date")
                continue

            # Filter available slots
            available_slots = []
            for slot_btn in time_slot_buttons:
                slot_class = slot_btn.get_attribute("class").lower()
                slot_text  = slot_btn.text.strip()
                slot_disabled = (
                    "disabled" in slot_class or "unavailable" in slot_class
                    or "cursor-not-allowed" in slot_class or "opacity" in slot_class
                    or "bg-red-100" in slot_class or "not available" in slot_text.lower()
                    or slot_btn.get_attribute("disabled") is not None
                )
                if not slot_disabled and slot_text:
                    available_slots.append((slot_btn, slot_text))
                    print(f"PASS: Available time slot: {slot_text}")
                else:
                    print(f"INFO: Unavailable time slot: {slot_text}")

            if not available_slots:
                print(f"INFO: No available time slots for date {day}, trying next date")
                continue

            # Prefer 6:00 PM, else first available
            selected_slot_btn, selected_slot_text = available_slots[0]
            for slot_btn, slot_text in available_slots:
                if "6:00 PM" in slot_text or "6 PM" in slot_text or "18:00" in slot_text:
                    selected_slot_btn, selected_slot_text = slot_btn, slot_text
                    break

            self.driver.execute_script("arguments[0].scrollIntoView({block:'center'});", selected_slot_btn)
            time.sleep(0.5)
            self.driver.execute_script("arguments[0].click();", selected_slot_btn)
            print(f"PASS: Time slot selected: {selected_slot_text}")
            time.sleep(1)

            # Confirm booking
            try:
                confirm_btn = self.wait.until(EC.element_to_be_clickable(self.CONFIRM_BTN))
            except Exception:
                try:
                    confirm_btn = self.driver.find_element(
                        By.XPATH,
                        "//button[contains(translate(text(),'abcdefghijklmnopqrstuvwxyz','ABCDEFGHIJKLMNOPQRSTUVWXYZ'),'CONFIRM')]"
                    )
                except Exception:
                    print("FAIL: Confirm Booking button not found")
                    continue

            self.driver.execute_script("arguments[0].scrollIntoView({block:'center'});", confirm_btn)
            time.sleep(0.5)
            self.driver.execute_script("arguments[0].click();", confirm_btn)
            print("PASS: Confirm Booking button clicked")
            booking_confirmed = True
            break

        time.sleep(2)
        if booking_confirmed:
            print("PASS: Booking successfully confirmed")
        else:
            print("FAIL: No available time slot found — booking could not be completed")

        # Back to homepage
        back_btn = self.wait.until(EC.element_to_be_clickable(self.BACK_HOME_FINAL))
        back_btn.click()
        print("PASS: Successfully back to the home page")
        time.sleep(2)
