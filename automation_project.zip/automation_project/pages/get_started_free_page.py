from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select
import time
import random


class GetStartedFreePage:
    """Locators and actions for the Sign-up (Get Started Free) page."""

    # ── Locators ──────────────────────────────────────────────────────
    HEADING          = (By.XPATH, "//*[contains(text(),'Create your free account')]")
    STEP_INDICATOR   = (By.XPATH, '//*[@id="root"]/div/main/div/div/div[1]/div')
    TOS_LINK         = (By.XPATH, "//a[contains(text(),'Terms of Service')]")
    PRIVACY_LINK     = (By.XPATH, "//a[contains(text(),'Privacy Policy')]")
    BACK_LINK        = (By.XPATH, "//*[contains(text(),'Back to Homepage')]")

    EMAIL_FIELD      = (By.NAME, "email")
    PASSWORD_FIELD   = (By.NAME, "password")
    CONFIRM_PASS     = (By.NAME, "confirmPassword")
    SUBMIT_BTN       = (By.XPATH, '//*[@id="root"]/div/main/div/div/div[2]/form/button')

    OTP_FIELD        = (By.NAME, "otp")
    OTP_VALIDATION   = (By.XPATH, '//*[@id="root"]/div/main/div/div/div[2]/form/p')
    VERIFY_OTP_BTN   = (By.XPATH, '//*[@id="root"]/div/main/div/div/div[2]/form/button')

    STEP2_HEADING    = (By.CSS_SELECTOR, "#root > div > main > div > div > div.bg-white.border.border-gray-200.rounded-lg.p-8.space-y-6 > h2")
    FIRST_LAST_NAME  = (By.NAME, "firstLastName")
    COMPANY_NAME     = (By.NAME, "companyName")
    INDUSTRY_DD      = (By.NAME, "industry")
    TEAM_SIZE_DD     = (By.NAME, "teamSize")
    COUNTRY_DD       = (By.NAME, "countryName")
    ADDRESS_LINE_1   = (By.NAME, "addressLine1")
    ADDRESS_LINE_2   = (By.NAME, "addressLine2")
    CITY_FIELD       = (By.NAME, "city")
    POSTAL_ZIP       = (By.NAME, "zipOrPostal")
    PHONE_NUMBER     = (By.NAME, "phoneNumber")
    CONTINUE_BTN     = (By.XPATH, '//*[@id="root"]/div/main/div/div/div[2]/form/button')

    START_FREE_BTN   = (By.XPATH, "//button[contains(.,'Start Free Trial')]")

    INDUSTRY_VALUES = [
        "Select Industry", "Real State", "Construction",
        "Manufacturing", "Professional Services", "Retail",
    ]

    TEAM_SIZE_VALUES = [
        "Select Team Size", "1-5 people", "6-20 people",
        "21-50 people", "51-200 people", "200+ people",
    ]

    MODULES = [
        "Inventory Management", "CRM & Sales", "Finance & Accounting",
        "Analytics & Reporting", "Project Management", "Workflow Automation",
    ]

    def __init__(self, driver, wait, base_url):
        self.driver   = driver
        self.wait     = wait
        self.base_url = base_url

    # ── Step 1: Page Load ─────────────────────────────────────────────

    def check_page_loaded(self):
        try:
            heading = self.wait.until(EC.visibility_of_element_located(self.HEADING))
            status = "PASS" if heading.is_displayed() else "FAIL"
            print(f"{status}: 'Create your free account' page loaded successfully")
        except Exception:
            print("FAIL: Page did not load correctly")

    def check_step_indicator(self):
        try:
            step = self.wait.until(EC.visibility_of_element_located(self.STEP_INDICATOR))
            status = "PASS" if step.is_displayed() else "FAIL"
            print(f"{status}: Step indicator is visible")
        except Exception:
            print("FAIL: Step indicator not found")

    def check_tos_and_privacy_links(self):
        try:
            tos = self.wait.until(EC.visibility_of_element_located(self.TOS_LINK))
            print("PASS: 'Terms of Service' link is visible" if tos.is_displayed() else "FAIL: TOS link not visible")
        except Exception:
            print("FAIL: 'Terms of Service' link not found")

        try:
            pp = self.driver.find_element(*self.PRIVACY_LINK)
            print("PASS: 'Privacy Policy' link is visible" if pp.is_displayed() else "FAIL: Privacy Policy link not visible")
        except Exception:
            print("FAIL: 'Privacy Policy' link not found")

    def check_back_to_homepage(self):
        try:
            link = self.wait.until(EC.visibility_of_element_located(self.BACK_LINK))
            print("PASS: 'Back to Homepage' link is visible")
            link.click()
            time.sleep(2)
            expected = self.base_url + "/"
            if self.driver.current_url == expected:
                print("PASS: 'Back to Homepage' navigates correctly")
            else:
                print("FAIL: 'Back to Homepage' navigation failed")
                print("INFO: Current URL:", self.driver.current_url)
        except Exception:
            print("FAIL: 'Back to Homepage' link not found")

    # ── Step 1: Credentials ───────────────────────────────────────────

    def fill_credentials(self, email, password):
        self.driver.get(self.base_url + "/signup")
        time.sleep(2)

        email_field = self.wait.until(EC.visibility_of_element_located(self.EMAIL_FIELD))
        print("PASS: Work Email field is visible")
        email_field.clear()
        email_field.send_keys(email)
        time.sleep(1)
        status = "PASS" if email_field.get_attribute("value") == email else "FAIL"
        print(f"{status}: Work Email field accepts input correctly")

        password_field = self.wait.until(EC.visibility_of_element_located(self.PASSWORD_FIELD))
        print("PASS: Password field is visible")
        password_field.clear()
        password_field.send_keys(password)
        time.sleep(1)
        status = "PASS" if password_field.get_attribute("value") == password else "FAIL"
        print(f"{status}: Password field accepts input correctly")

        confirm_pass = self.wait.until(EC.visibility_of_element_located(self.CONFIRM_PASS))
        print("PASS: Confirm Password field is visible")
        confirm_pass.clear()
        confirm_pass.send_keys(password)
        time.sleep(1)
        status = "PASS" if confirm_pass.get_attribute("value") == password else "FAIL"
        print(f"{status}: Confirm Password field accepts input correctly")

        self.driver.find_element(*self.SUBMIT_BTN).click()
        time.sleep(2)
        print("PASS: Form submitted, moved to next step")

    # ── Step 1: OTP ───────────────────────────────────────────────────

    def test_otp_field(self, test_otp):
        otp_field = self.wait.until(EC.visibility_of_element_located(self.OTP_FIELD))
        print("PASS: OTP field is visible")
        otp_field.clear()
        otp_field.send_keys(test_otp)
        time.sleep(1)
        status = "PASS" if otp_field.get_attribute("value") == test_otp else "FAIL"
        print(f"{status}: OTP field accepts input correctly")

    def test_resend_otp(self):
        print("INFO: Waiting 3 minutes for OTP expiry...")
        time.sleep(180)
        validation_msg = self.wait.until(EC.visibility_of_element_located(self.OTP_VALIDATION))
        status = "Pass" if validation_msg.is_displayed() else "Fail"
        print(f"{status}: Validation message is visible")
        self.wait.until(EC.visibility_of_element_located(self.VERIFY_OTP_BTN)).click()
        time.sleep(2)
        print("PASS: Resend OTP successfully")

    def verify_otp(self):
        self.wait.until(EC.visibility_of_element_located(self.VERIFY_OTP_BTN)).click()
        time.sleep(2)
        print("PASS: Verify OTP, moved to next step")

    # ── Step 2: Profile info ──────────────────────────────────────────

    def check_step2_heading(self):
        heading = self.driver.find_element(*self.STEP2_HEADING)
        status = "✅" if heading.is_displayed() else "❌"
        print(f"{status} Heading is visible")

    def test_first_last_name(self, test_name):
        print("First and Last name:")
        field = self.wait.until(EC.visibility_of_element_located(self.FIRST_LAST_NAME))
        field.clear()
        self.driver.find_element(*self.CONTINUE_BTN).click()
        try:
            msg = self.wait.until(EC.visibility_of_element_located(
                (By.XPATH, '//*[@id="root"]/div/main/div/div/div[2]/form/div[1]/p')
            ))
            print("PASS: TEST CASE 1 PASSED - Validation message displayed for empty mandatory field")
        except Exception:
            print("FAIL: TEST CASE 1 FAILED - No validation message displayed")

        field.send_keys(test_name)
        entered = field.get_attribute("value")
        status = "PASS" if entered == test_name else "FAIL"
        print(f"{status}: TEST CASE 2 PASSED - First and Last Name entered successfully")
        time.sleep(2)

    def test_company_name(self, test_company):
        print("Company name:")
        field = self.wait.until(EC.visibility_of_element_located(self.COMPANY_NAME))
        field.clear()
        self.driver.find_element(*self.CONTINUE_BTN).click()
        try:
            msg = self.wait.until(EC.visibility_of_element_located(
                (By.XPATH, '//*[@id="root"]/div/main/div/div/div[2]/form/div[2]/p')
            ))
            print("PASS: TEST CASE 1 PASSED - Validation message displayed for empty mandatory field")
        except Exception:
            print("FAIL: TEST CASE 1 FAILED - No validation message displayed")

        field = self.driver.find_element(*self.COMPANY_NAME)
        field.send_keys(test_company)
        entered = field.get_attribute("value")
        status = "PASS" if entered == test_company else "FAIL"
        print(f"{status}: TEST CASE 2 PASSED - Company Name entered successfully")
        time.sleep(2)

    def test_industry_dropdown(self):
        print("\n===== INDUSTRY DROPDOWN TEST STARTED =====")
        dd = self.wait.until(EC.visibility_of_element_located(self.INDUSTRY_DD))
        select = Select(dd)

        select.select_by_visible_text("Select Industry")
        self.driver.find_element(*self.CONTINUE_BTN).click()
        time.sleep(1)
        try:
            msg = self.wait.until(EC.visibility_of_element_located(
                (By.XPATH, '//*[@id="root"]/div/main/div/div/div[2]/form/div[3]/p')
            ))
            status = "✅ TEST CASE 1 PASSED" if msg.is_displayed() else "❌ TEST CASE 1 FAILED"
            print(f"{status} - Validation message displayed")
        except Exception:
            print("❌ TEST CASE 1 FAILED - Validation message not found")

        for value in self.INDUSTRY_VALUES[1:]:
            select.select_by_visible_text(value)
            selected = select.first_selected_option.text
            status = "✅ PASS" if selected == value else "❌ FAIL"
            print(f"{status} - '{value}' selected successfully")
            time.sleep(2)

    def test_team_size_dropdown(self):
        print("\n===== TEAM SIZE DROPDOWN TEST STARTED =====")
        dd = self.wait.until(EC.visibility_of_element_located(self.TEAM_SIZE_DD))
        select = Select(dd)

        select.select_by_visible_text("Select Team Size")
        self.driver.find_element(*self.CONTINUE_BTN).click()
        time.sleep(1)
        try:
            msg = self.wait.until(EC.visibility_of_element_located(
                (By.XPATH, '//*[@id="root"]/div/main/div/div/div[2]/form/div[4]/p')
            ))
            status = "✅ TEST CASE 1 PASSED" if msg.is_displayed() else "❌ TEST CASE 1 FAILED"
            print(f"{status} - Validation message displayed")
        except Exception:
            print("❌ TEST CASE 1 FAILED - Validation message not found")

        for value in self.TEAM_SIZE_VALUES[1:]:
            select.select_by_visible_text(value)
            selected = select.first_selected_option.text
            status = "✅ PASS" if selected == value else "❌ FAIL"
            print(f"{status} - '{value}' selected successfully")
            time.sleep(2)

    def test_country_dropdown(self):
        dd = self.wait.until(EC.visibility_of_element_located(self.COUNTRY_DD))
        select = Select(dd)

        default = select.first_selected_option.text
        print("PASS: Default country is Bangladesh" if default == "Bangladesh" else "FAIL: Default country is not Bangladesh")
        print("PASS: Country dropdown is clickable" if dd.is_enabled() else "FAIL: Country dropdown is not clickable")

        all_options = select.options
        print("\nAvailable Countries:")
        for opt in all_options:
            print(opt.text)
        print("\nPASS: Country list loaded successfully" if len(all_options) > 0 else "\nFAIL: Country list is empty")

        select.select_by_visible_text("India")
        selected = select.first_selected_option.text
        print("PASS: India selected successfully" if selected == "India" else "FAIL: Country selection failed")
        time.sleep(3)

    def test_address_fields(self, addr1, addr2, city, postal, phone):
        # Address Line 1
        field = self.wait.until(EC.visibility_of_element_located(self.ADDRESS_LINE_1))
        field.clear()
        self.driver.find_element(*self.CONTINUE_BTN).click()
        time.sleep(1)
        try:
            msg = self.wait.until(EC.visibility_of_element_located((By.XPATH, "//p[text()='Address Line 1 is required']")))
            print("PASS:", msg.text)
        except Exception:
            print("FAIL: Validation message not found")

        field = self.wait.until(EC.visibility_of_element_located(self.ADDRESS_LINE_1))
        field.send_keys(addr1)
        status = "PASS" if field.get_attribute("value") == addr1 else "FAIL"
        print(f"{status}: Address Line 1 entered successfully")
        time.sleep(2)

        # Address Line 2
        field2 = self.wait.until(EC.visibility_of_element_located(self.ADDRESS_LINE_2))
        field2.send_keys(addr2)
        status = "PASS" if field2.get_attribute("value") == addr2 else "FAIL"
        print(f"{status}: Address Line 2 entered successfully")
        time.sleep(2)

        # City
        city_field = self.wait.until(EC.visibility_of_element_located(self.CITY_FIELD))
        city_field.clear()
        self.driver.find_element(*self.CONTINUE_BTN).click()
        time.sleep(1)
        try:
            msg = self.wait.until(EC.visibility_of_element_located((By.XPATH, "//p[text()='City name is required']")))
            print("PASS:", msg.text)
        except Exception:
            print("FAIL: Validation message not found")

        city_field = self.wait.until(EC.visibility_of_element_located(self.CITY_FIELD))
        city_field.send_keys(city)
        status = "PASS" if city_field.get_attribute("value") == city else "FAIL"
        print(f"{status}: City entered successfully")
        time.sleep(2)

        # Postal Code
        postal_field = self.wait.until(EC.visibility_of_element_located(self.POSTAL_ZIP))
        postal_field.clear()
        self.driver.find_element(*self.CONTINUE_BTN).click()
        time.sleep(1)
        try:
            msg = self.wait.until(EC.visibility_of_element_located((By.XPATH, "//p[text()='Zip or Postal Code is required']")))
            print("PASS:", msg.text)
        except Exception:
            print("FAIL: Validation message not found")

        postal_field = self.wait.until(EC.visibility_of_element_located(self.POSTAL_ZIP))
        postal_field.send_keys(postal)
        status = "PASS" if postal_field.get_attribute("value") == postal else "FAIL"
        print(f"{status}: Postal Code / ZIP entered successfully")
        time.sleep(2)

        # Phone
        phone_field = self.wait.until(EC.visibility_of_element_located(self.PHONE_NUMBER))
        phone_field.send_keys(phone)
        entered = phone_field.get_attribute("value")
        status = "PASS" if phone in entered else "FAIL"
        print(f"{status}: Phone Number entered successfully")
        time.sleep(2)

        self.driver.find_element(*self.CONTINUE_BTN).click()
        time.sleep(2)

    # ── Step: Module selection ────────────────────────────────────────

    def test_module_selection(self):
        button = self.wait.until(EC.visibility_of_element_located(self.START_FREE_BTN))
        print("\nInitial Button Text:")
        print(button.text)

        print("\n===== SELECT MODULE TEST =====")
        expected_count = 0
        for module in self.MODULES:
            card = self.wait.until(EC.element_to_be_clickable((By.XPATH, f"//*[contains(text(),'{module}')]")))
            card.click()
            time.sleep(1)
            expected_count += 1
            updated_text = button.text
            print(f"\nClicked Module: {module}")
            print("Updated Button Text:", updated_text)
            print(f"{'PASS' if str(expected_count) in updated_text else 'FAIL'}: Count updated to {expected_count}")
            print(f"{'PASS' if button.is_enabled() else 'FAIL'}: Button Enabled")

        print("\n===== UNSELECT MODULE TEST =====")
        for module in reversed(self.MODULES):
            card = self.wait.until(EC.element_to_be_clickable((By.XPATH, f"//*[contains(text(),'{module}')]")))
            card.click()
            time.sleep(1)
            expected_count -= 1
            updated_text = button.text
            print(f"\nUnselected Module: {module}")
            print("Updated Button Text:", updated_text)
            print(f"{'PASS' if str(expected_count) in updated_text else 'FAIL'}: Count decreased to {expected_count}")

        print("\n===== FINAL BUTTON CHECK =====")
        print("Final Button Text:", button.text)
        if expected_count == 0:
            print(f"{'PASS' if not button.is_enabled() else 'FAIL'}: Button Disabled Again")

        time.sleep(5)

        # Start with a random module
        random_module = random.choice(self.MODULES)
        print("Selected module:", random_module)
        card = self.wait.until(EC.element_to_be_clickable((By.XPATH, f"//*[contains(text(),'{random_module}')]")))
        card.click()
        time.sleep(1)

        start_btn = self.wait.until(EC.element_to_be_clickable(self.START_FREE_BTN))
        start_btn.click()
        print("Start Free Trial button clicked successfully")
        time.sleep(2)
