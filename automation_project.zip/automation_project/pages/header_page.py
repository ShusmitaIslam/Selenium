from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC


class HeaderPage:
    """Locators and actions for the site header."""

    # ── Locators ──────────────────────────────────────────────────────
    LOGO        = (By.CSS_SELECTOR, "#root > div")
    NAV_PRODUCT = (By.CSS_SELECTOR, "nav a:nth-child(1)")
    NAV_PRICING = (By.CSS_SELECTOR, "nav a:nth-child(2)")
    DEMO_BTN    = (By.CSS_SELECTOR, "a.border")
    START_BTN   = (By.CSS_SELECTOR, r"a.bg-\[\#761cc3\]")

    SECTION_PRODUCT = (By.CSS_SELECTOR, "#product")
    SECTION_PRICING = (By.CSS_SELECTOR, "#pricing")

    def __init__(self, driver, wait):
        self.driver = driver
        self.wait   = wait

    # ── Visibility checks ─────────────────────────────────────────────

    def check_all_elements_visible(self):
        self.wait.until(EC.visibility_of_element_located(self.LOGO))
        print("✅ Logo is visible")

        self.wait.until(EC.visibility_of_element_located(self.NAV_PRODUCT))
        print("✅ Product menu is visible")

        self.wait.until(EC.visibility_of_element_located(self.NAV_PRICING))
        print("✅ Pricing menu is visible")

        self.wait.until(EC.visibility_of_element_located(self.DEMO_BTN))
        print("✅ Book a Demo button is visible")

        self.wait.until(EC.visibility_of_element_located(self.START_BTN))
        print("✅ Get Started button is visible")

    # ── Navigation actions ────────────────────────────────────────────

    def click_product_and_verify_scroll(self):
        import time
        product = self.wait.until(EC.visibility_of_element_located(self.NAV_PRODUCT))
        product.click()
        time.sleep(3)
        section = self.wait.until(EC.presence_of_element_located(self.SECTION_PRODUCT))
        if section.is_displayed():
            print("✅ Product section clickable & scroll works")

    def click_pricing_and_verify_scroll(self):
        import time
        pricing = self.wait.until(EC.visibility_of_element_located(self.NAV_PRICING))
        pricing.click()
        time.sleep(1)
        section = self.wait.until(EC.presence_of_element_located(self.SECTION_PRICING))
        if section.is_displayed():
            print("✅ Pricing section clickable & scroll works")

    def click_book_a_demo(self, expected_url):
        import time
        demo_btn = self.wait.until(EC.visibility_of_element_located(self.DEMO_BTN))
        demo_btn.click()
        time.sleep(1)
        self.wait.until(EC.url_to_be(expected_url))
        if self.driver.current_url == expected_url:
            print("✅ User successfully redirected to Book a Demo page")
        else:
            print("❌ Navigation failed")

    def click_get_started(self, expected_url):
        import time
        start_btn = self.wait.until(EC.visibility_of_element_located(self.START_BTN))
        start_btn.click()
        time.sleep(1)
        self.wait.until(EC.url_to_be(expected_url))
        if self.driver.current_url == expected_url:
            print("✅ User successfully redirected to Get Started Free page")
        else:
            print("❌ Navigation failed")
