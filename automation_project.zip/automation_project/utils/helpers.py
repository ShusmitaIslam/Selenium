from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from config.config import WAIT_TIMEOUT
import time


def get_driver():
    driver = webdriver.Chrome()
    driver.maximize_window()
    return driver


def get_wait(driver):
    return WebDriverWait(driver, WAIT_TIMEOUT)


def go_back_home(driver, wait, base_url):
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support import expected_conditions as EC
    logo = wait.until(EC.element_to_be_clickable(
        (By.XPATH, '//*[@id="root"]/div/nav/div/a/img')
    ))
    logo.click()
    wait.until(EC.url_to_be(base_url + "/"))
    time.sleep(1)


def check_redirect(driver, wait, expected_url, label):
    from selenium.webdriver.support import expected_conditions as EC
    try:
        wait.until(EC.url_to_be(expected_url))
        if driver.current_url == expected_url:
            print(f"✅ {label}: Redirection successful")
        else:
            print(f"❌ {label}: Redirection failed")
    except Exception:
        print(f"❌ {label}: Timeout — URL did not change to {expected_url}")


def check_url_changed(driver, wait, old_url, label):
    from selenium.webdriver.support import expected_conditions as EC
    try:
        wait.until(EC.url_changes(old_url))
        if driver.current_url != old_url:
            print(f"✅ {label}: Redirection successful")
        else:
            print(f"❌ {label}: Redirection failed")
    except Exception:
        print(f"❌ {label}: URL did not change")
