BASE_URL = "http://192.168.71.152:3000"

WAIT_TIMEOUT = 10
SLEEP_SHORT  = 1
SLEEP_MEDIUM = 2
SLEEP_LONG   = 3

TEST_DATA = {
    "name"            : "Shusmita Islam",
    "email"           : "shusmita@example.com",
    "work_email"      : "shusmita.islam@wyzetechltd.com",
    "password"        : "Test@1234",
    "company"         : "Shusmita Enterprise",
    "company_signup"  : "Wyze Tech Ltd.",
    "otp"             : "111111",
    "address_line_1"  : "House 12, Road 5",
    "address_line_2"  : "House 22, Road 50",
    "city"            : "Dhaka",
    "postal_code"     : "1215",
    "phone_number"    : "1557678258",
}
